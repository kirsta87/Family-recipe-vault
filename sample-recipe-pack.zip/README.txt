Recipe Vault sample pack. Keep manifest.json at the ZIP root and images in any safe folder. The manifest image field connects each recipe to its image.
